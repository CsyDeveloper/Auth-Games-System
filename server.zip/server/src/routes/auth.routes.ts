import { Router } from "express";
import { playersCollection } from "../db";
import { register, login } from "../auth/auth";
import { config } from "../config";

export const authRouter = Router();

// POST /register  corpo {"name": "..."}  ->  200 {"id": "...", "secret": "..."}
authRouter.post("/register", async (req, res) => {
  const name = req.body?.name;

  if (
    typeof name !== "string" ||
    name.trim().length === 0 ||
    name.trim().length > config.nameMaxLength
  ) {
    res.status(400).json({ error: "nome invalido" });
    return;
  }

  try {
    const result = await register(playersCollection(), name.trim());
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "erro interno" });
  }
});

// POST /login  corpo {"id": "...", "secret": "..."}  ->  200 com o perfil, ou 401
authRouter.post("/login", async (req, res) => {
  const { id, secret } = req.body ?? {};

  if (typeof id !== "string" || typeof secret !== "string") {
    res.status(400).json({ error: "dados invalidos" });
    return;
  }

  try {
    const player = await login(playersCollection(), id, secret);

    if (!player) {
      res.status(401).json({ error: "invalido" });
      return;
    }

    // Nunca devolva secretHash para o cliente
    res.json({
      id: player._id?.toString(),
      name: player.name,
      crowns: player.crowns,
      level: player.level,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "erro interno" });
  }
});
