import express from "express";
import { config } from "./config";
import { connectDb } from "./db";
import { authRouter } from "./routes/auth.routes";

async function main(): Promise<void> {
  await connectDb();

  const app = express();
  app.use(express.json({ limit: "10kb" }));
  app.use(authRouter);

  app.listen(config.port, () => {
    console.log(`Servidor rodando na porta ${config.port}`);
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
