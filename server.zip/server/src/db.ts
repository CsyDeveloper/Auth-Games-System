import { MongoClient, Collection } from "mongodb";
import { config } from "./config";
import { Player } from "./auth/auth";

const client = new MongoClient(config.mongoUri);

export async function connectDb(): Promise<void> {
  await client.connect();
  // _id já é indexado automaticamente; este índice ajuda a buscar por nick
  await playersCollection().createIndex({ name: 1 });
}

export function playersCollection(): Collection<Player> {
  return client.db(config.dbName).collection<Player>("players");
}
