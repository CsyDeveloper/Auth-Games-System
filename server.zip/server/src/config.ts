// Configurações do servidor. Em produção, defina as variáveis de ambiente.
export const config = {
  port: Number(process.env.PORT ?? 3000),
  mongoUri: process.env.MONGO_URI ?? "mongodb://localhost:27017",
  dbName: process.env.DB_NAME ?? "stumbleice",
  nameMaxLength: 16,
};
